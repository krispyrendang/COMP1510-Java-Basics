[Taswinder Singh Dhaliwal], [A01239263], [1C], [Feb 13, 2022]

This assignment is [100]% complete.


------------------------
Question one (PhoneNumbers) status:

[complete]

------------------------
Question two (Balloon) status:

[complete]

------------------------
Question three (Cylinder) status:

[complete]

------------------------
Question four (Box) status:

[complete]

------------------------
Question five (DiscountCalculator) status:

[complete]
