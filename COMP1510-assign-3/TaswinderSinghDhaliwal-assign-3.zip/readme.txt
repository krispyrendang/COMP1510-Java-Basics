[Taswinder Singh Dhaliwal], [A01239263], [1C], [Mar 27, 2022]

This assignment is [45]% complete.


------------------------
Question one (WordCounter) status:

[complete]

------------------------
Question two (Primes) status:

[not complete]
[Error in calculatePrimes. Unable to calculate which numbers are prime numbers.]

------------------------
Question three (TestStudent and supporting classes) status:

[not complete]
[not attempted]

------------------------
Question four (TestCourse and supporting classes) status:

[not complete]
[not attempted]

------------------------
