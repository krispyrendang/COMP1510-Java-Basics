package q3;


/** Stores a message in a long array.
 * @author Taswinder Singh Dhaliwal Set 1C
 * @version 1.0
 */
public class Message {
    
    /** a packed string of MIXChars. */
    private long[] msg;
    
    /** number of chars in message object. */
    private int count;

    /** Constructor that initialize the array and char count.
     * @param m - input MIXChar array.
     */
    public Message(MIXChar[] m) {
        
    }
    
    /** Constructor that initialize the array and char count.
     * @param s - packed 11 MIXChar characters per long.
     */
    public Message(String s) {
        
    }
    
    /**
     * Returns a string corresponding to the characters in the message.
     * @return String - message description
     */
    public String toString() {
        String results = "";
        
        return results;
    }
    
    /** returns a string.
     *  which is the instance long[] formatted as 
     *  unsigned integers and separated by spaces.
     * @return String of unsigned integers and spaces.
     */
    public String toLongs() {
        String results = "";
        
        return results;
    }
    
    
    
    
    
}
