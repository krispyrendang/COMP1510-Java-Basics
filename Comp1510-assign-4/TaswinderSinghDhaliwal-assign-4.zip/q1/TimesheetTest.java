package q1;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * <p>Tests the time sheet program.</p>
 *
 * @author Taswinder Singh Dhaliwal Set 1C
 * @version 1.0
 */
public class TimesheetTest {
    
    @Test
    public void firstTest() {
        assertTrue(true);
    }
}
