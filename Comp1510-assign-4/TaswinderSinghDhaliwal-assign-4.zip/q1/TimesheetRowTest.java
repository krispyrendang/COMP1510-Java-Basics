package q1;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * <p>Test the time sheet row program.</p>
 *
 * @author Taswinder Singh Dhaliwal Set 1C
 * @version 1.0
 */
public class TimesheetRowTest {

    @Test
    public void firstTest() {
        assertTrue(true);
    }
}
