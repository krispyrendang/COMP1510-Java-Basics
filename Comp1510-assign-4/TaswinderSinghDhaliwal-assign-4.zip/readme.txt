[Taswinder Singh Dhaliwal], [A01239263], [1C], [Apr 10, 2022]

This assignment is [60]% complete.


------------------------
Question one (Timesheet) status:

[not complete]
[Only made the methods and could not run it. I do not understand the requirements.]

------------------------
Question two (Exponential) status:

[complete]

------------------------
Question three (TestMIXChar) status:

[not complete]
[TestMIXChar is able to pass in command-line arguments. Not able to do the rest besides creating a method stub as required.]
