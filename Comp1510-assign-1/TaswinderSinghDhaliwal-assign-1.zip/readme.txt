[Taswinder Singh Dhaliwal], [A01239263], [1C], [Jan 30, 2022]

This assignment is [100]% complete.


------------------------
Question one (Change) status:

[complete]

------------------------
Question two (SecondsConvert) status:

[complete]

------------------------
Question three (Arithmetic) status:

[complete]

------------------------
Question four (Sqrt) status:

[complete]

------------------------
Question five (Pack) status:

[complete]
